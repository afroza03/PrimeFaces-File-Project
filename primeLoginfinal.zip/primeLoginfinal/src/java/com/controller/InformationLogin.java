/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.dao.ServiceLogin;
import com.model.Userlogin;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean (name="ulogin")
@SessionScoped
public class InformationLogin {
    List<Userlogin> searchlist=new ArrayList<>();
    
    private int id;
    private String email;
    private String pass;
    private String search;

    public InformationLogin() {
    }

    
    
   @PostConstruct
    public void init(){
        searchlist = in.getAll();
          System.out.println("---- size "+searchlist.size());
    }
    public List<String> testCompleteMethod(String input) {
        System.out.println("------ "+input);
        List<String> suggesstions = new ArrayList<>();
        for(Userlogin e: searchlist) {
            if(!e.getEmail().isEmpty() && e.getEmail().toLowerCase().contains(input.toLowerCase())) {
                suggesstions.add(e.getId()+"-"+e.getEmail());
            }
        }
        return suggesstions;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    
    
    
    
    public InformationLogin(String email, String pass) {
        this.email = email;
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public String reset(){
        return "";
    }
    public String Login(){
        return "";
    }
    
    ServiceLogin in= new ServiceLogin();
    
    
    public String signup(){
        
        Userlogin ul = new Userlogin();
        ul.setEmail(email);
        ul.setId(id);
        ul.setPassword(pass);
        in.signUp(ul);
        
      return "index";
    }
    
      public String login() {
        boolean respose = in.login(email, pass);
        if(respose) {
            
            return "signUp";
        }
        return "search";
    }
}
