/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.model.Userlogin;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class ServiceLogin {
   SessionFactory sessionfac= HibernateUtil.getSessionFactory();
           
           
   public boolean login (String email,String password){
       boolean result=false;
       Session sess=sessionfac.openSession();
       Query query = sess.createQuery("From Userlogin  u where u.email= :em AND "+"u.password= :pass");
       query.setParameter("em",email);
       query.setParameter("pass",password);
       List<Userlogin> lists=query.list();
       
       for(Userlogin log: lists){
           result=true;
       }
       sess.close();
       return result;
   }  

   
   public List<Userlogin> getAll(){
       List<Userlogin> ul = new ArrayList<>();
       Session sess = sessionfac.openSession();
       Query query = sess.createQuery("From Userlogin");
       ul= query.list();
//       for(Userlogin u:ul){
//           ul.add(u);
//       }
       sess.close();
       return ul;
   }
   
       public void  signUp(Userlogin ul) {
       boolean result = false;
       Session sess = sessionfac.openSession();
       sess.beginTransaction();
       sess.save(ul);
       sess.getTransaction().commit();
       sess.close();
    }
   
   
           
}
